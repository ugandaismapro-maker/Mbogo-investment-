# Mbogo Investment — Android starter project

This is a native Android (Kotlin) starter project. It is a customer-facing app shell with:
- Home dashboard and UGX 5,000 minimum investment amount shown as an informational starting point
- Portfolio summary (demo data)
- Deposit and withdrawal request screens (demo only)
- Transaction history (demo data)

IMPORTANT:
- This starter does NOT accept, hold, send, or invest real money.
- It does NOT connect to MTN MoMo, Airtel Money, a bank, or a backend.
- Demo balances and transaction records are sample values only.
- Before real-money use, add a secure server/backend, verified payment-provider APIs, authentication, audit logs, privacy/security controls, and confirm applicable Ugandan financial licensing/legal requirements.
- Never use a hardcoded owner password in a live app.

## Open/build
Open this folder in Android Studio on a computer, let Gradle sync, then Build > Build APK(s).
The Gradle wrapper is not included in this source ZIP. Android Studio can import the project and generate wrapper files.
