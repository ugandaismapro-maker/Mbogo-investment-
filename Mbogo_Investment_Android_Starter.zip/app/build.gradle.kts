plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "ug.mbogo.investment"
    compileSdk = 35
    defaultConfig {
        applicationId = "ug.mbogo.investment"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
