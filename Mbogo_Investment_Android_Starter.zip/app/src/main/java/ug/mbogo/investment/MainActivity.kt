package ug.mbogo.investment

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val navy = Color.rgb(16, 39, 73)
    private val green = Color.rgb(21, 128, 82)
    private val pale = Color.rgb(243, 247, 250)
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pale)
            setPadding(20, 22, 20, 20)
        }
        val header = TextView(this).apply {
            text = title
            textSize = 25f
            setTextColor(navy)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 4, 0, 18)
        }
        root.addView(header)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun text(value: String, size: Float = 16f, color: Int = Color.DKGRAY, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 8, 0, 8)
        }

    private fun card(title: String, body: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            setPadding(16, 12, 16, 12)
        }
        box.addView(text(title, 15f, green, true))
        box.addView(text(body, 21f, navy, true))
        val params = LinearLayout.LayoutParams(-1, -2)
        params.bottomMargin = 12
        root.addView(box, params)
    }

    private fun button(label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(green)
            setOnClickListener { action() }
        }
        val p = LinearLayout.LayoutParams(-1, -2)
        p.bottomMargin = 8
        root.addView(b, p)
    }

    private fun showHome() {
        base("Mbogo Investment")
        root.addView(text("Your money goals, in one place", 16f, Color.DKGRAY))
        card("Available balance (demo)", "UGX 0")
        card("Portfolio value (demo)", "UGX 0")
        card("Minimum amount", "UGX 5,000")
        root.addView(text("Demo version — no real money is processed.", 13f, Color.rgb(160, 70, 20)))
        button("Request a deposit") { showRequest("Deposit") }
        button("Request a withdrawal") { showRequest("Withdrawal") }
        button("Transaction history") { showHistory() }
        button("About / safety") { showAbout() }
    }

    private fun showRequest(kind: String) {
        base(kind)
        root.addView(text("This is a demo request form. It will not move money.", 15f, Color.rgb(160, 70, 20)))
        root.addView(text("Amount (UGX)", 16f, navy, true))
        val amount = EditText(this).apply {
            hint = "Enter amount (minimum 5000)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        root.addView(amount)
        root.addView(text("Mobile money network", 16f, navy, true))
        val network = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("MTN Mobile Money", "Airtel Money", "Other / not selected"))
        }
        root.addView(network)
        if (kind == "Withdrawal") {
            root.addView(text("Mobile money phone number", 16f, navy, true))
            root.addView(EditText(this).apply {
                hint = "e.g. 2567XXXXXXXX"
                inputType = android.text.InputType.TYPE_CLASS_PHONE
            })
        }
        button("Submit demo request") {
            val value = amount.text.toString().toLongOrNull()
            if (value == null || value < 5000) {
                Toast.makeText(this, "Enter at least UGX 5,000", Toast.LENGTH_LONG).show()
            } else {
                AlertDialog.Builder(this)
                    .setTitle("Demo only")
                    .setMessage("$kind request for UGX $value has NOT been sent. Connect a secure backend and approved payment API before using real money.")
                    .setPositiveButton("OK", null).show()
            }
        }
        button("Back to home") { showHome() }
    }

    private fun showHistory() {
        base("Transaction history")
        root.addView(text("No transactions yet.", 17f, navy, true))
        root.addView(text("When connected to a secure backend, this page can show verified deposits, withdrawals, fees, status and timestamps. Sample data is not used here.", 15f))
        button("Back to home") { showHome() }
    }

    private fun showAbout() {
        base("About Mbogo Investment")
        root.addView(text("This is an early Android app shell for Mbogo Investment.", 17f, navy, true))
        root.addView(text("Before accepting customer funds, verify the legal and financial licensing requirements in Uganda. Never advertise guaranteed returns. Use a secure server, real payment-provider verification, protected owner access, and a complete audit trail.", 15f))
        root.addView(text("No login, real account, payment processing, or investment engine is connected in this starter.", 14f, Color.rgb(160, 70, 20)))
        button("Back to home") { showHome() }
    }
}
